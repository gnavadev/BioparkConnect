#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int contador; // variável de controle do loop

    for (contador = 1; contador <= 20; contador++)
    {
        printf("\n Mensagem %d ", contador);
    }
    return 0;
}